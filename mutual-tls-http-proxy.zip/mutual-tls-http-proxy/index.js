const fs = require('fs');
const httpProxy = require('http-proxy');

httpProxy.createProxyServer({
    target: {
        protocol: 'https:',
        host: 'localhost',
        port: 8444,
        pfx: fs.readFileSync('certs/client.p12'),
        passphrase: 'changeit',
    },
    secure: false,
    changeOrigin: false,
}).listen(8080);