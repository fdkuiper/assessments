const fs = require('fs');
const proxy = require('koa-proxies');
const keystore = fs.readFileSync('certs/client.p12');
const keystorePassword = 'changeit';

module.exports = {
    port: 8080,
    watch: true,
    nodeResolve: true,
    appIndex: 'index.html',
    middlewares: [
        proxy('/accounts', {
            target: {
                protocol: 'https:',
                host: 'localhost',
                port: 8444,
                pfx: keystore,
                passphrase: keystorePassword,
            },
            logs: false,
            events: {
                error(err, req, res) {
                    console.log(err);
                }
            }
        }),
    ],
};